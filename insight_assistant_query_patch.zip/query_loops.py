"""
query_loops.py

Query Ora's loop memory by combining semantic search (Qdrant) and structured filtering (SQLite).
"""

import argparse
from openai import OpenAI
from qdrant_client import QdrantClient
import sqlite3
import uuid

# Setup
client = OpenAI()
qdrant = QdrantClient(host="localhost", port=6333)
DB_PATH = "/Users/air/ea_assistant/loop_memory.db"
COLLECTION_NAME = "loop_embeddings"

def embed_query(text):
    response = client.embeddings.create(
        input=[text],
        model="text-embedding-3-small"
    )
    return response.data[0].embedding

def search_qdrant(embedding, top_k=5):
    results = qdrant.search(
        collection_name=COLLECTION_NAME,
        query_vector=embedding,
        limit=top_k,
        with_payload=True
    )
    return results

def filter_sqlite(loop_ids, status_filter=None):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    placeholders = ",".join(["?"] * len(loop_ids))
    query = f"SELECT id, summary, status, priority FROM loops WHERE id IN ({placeholders})"
    if status_filter:
        query += " AND status = ?"
        loop_ids.append(status_filter)
    cursor.execute(query, loop_ids)
    results = cursor.fetchall()
    conn.close()
    return results

def main():
    parser = argparse.ArgumentParser(description="Query loop memory semantically and structurally")
    parser.add_argument("query", type=str, help="Natural language query")
    parser.add_argument("--status", type=str, help="Optional status filter: open/closed", default=None)
    args = parser.parse_args()

    print(f"🔍 Query: {args.query}")
    embedding = embed_query(args.query)
    qdrant_results = search_qdrant(embedding)

    loop_ids = [hit.payload.get("loop_id") for hit in qdrant_results if "loop_id" in hit.payload]
    sqlite_data = filter_sqlite(loop_ids, args.status)

    print("\n🎯 Matched Loops:")
    for row in sqlite_data:
        print(f"- {row[0]} | {row[1][:80]}... | status: {row[2]} | priority: {row[3]}")

if __name__ == "__main__":
    main()
