"""
insert_to_qdrant.py

Embeds the summary and inserts it into a live Qdrant instance.
"""

from openai import OpenAI
from qdrant_client import QdrantClient
from qdrant_client.models import PointStruct, VectorParams, Distance
import os
import hashlib

client = OpenAI()
qdrant = QdrantClient(host="localhost", port=6333)

COLLECTION_NAME = "loop_embeddings"

def embed_text(text):
    response = client.embeddings.create(
        input=[text],
        model="text-embedding-3-small"
    )
    return response.data[0].embedding

def insert_to_qdrant(loop_id, summary, metadata):
    # Ensure collection exists
    qdrant.recreate_collection(
        collection_name=COLLECTION_NAME,
        vectors_config=VectorParams(size=1536, distance=Distance.COSINE)
    )

    vector = embed_text(summary)

    qdrant.upsert(
        collection_name=COLLECTION_NAME,
        points=[
            PointStruct(
                id=loop_id,
                vector=vector,
                payload={
                    "summary": summary,
                    "tags": metadata["tags"],
                    "status": metadata["status"],
                    "type": metadata["type"],
                    "priority": metadata["priority"],
                    "source": metadata["source"]
                }
            )
        ]
    )

    print(f"✅ Embedded and inserted {loop_id} into Qdrant collection '{COLLECTION_NAME}'")
