"""
weight_loops.py

Calculates and updates weights for all loops based on feedback, promotion, age, and status.
Updates SQLite and logs to loop_weights_log.md. YAML update optional (future toggle).
"""

import sqlite3
from datetime import date, datetime
from pathlib import Path

DB_PATH = "/Users/air/ea_assistant/loop_memory.db"
LOG_PATH = Path("/Users/air/AIR01/System/Logs/loop_weights_log.md")

def calculate_weight(status, created, feedback, promoted):
    weight = 0
    if feedback == "useful":
        weight += 1
    elif feedback == "false_positive":
        weight -= 3
    if promoted == "true":
        weight += 2
    if status == "open" and (date.today() - date.fromisoformat(created)).days > 30:
        weight -= 1
    return weight

def ensure_columns(cursor):
    cursor.execute("PRAGMA table_info(loops)")
    columns = [col[1] for col in cursor.fetchall()]
    if "weight" not in columns:
        cursor.execute("ALTER TABLE loops ADD COLUMN weight INTEGER")
    if "promoted" not in columns:
        cursor.execute("ALTER TABLE loops ADD COLUMN promoted TEXT")

def update_weights():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    ensure_columns(cursor)

    cursor.execute("SELECT id, status, created, feedback, priority, promoted FROM loops")
    rows = cursor.fetchall()

    LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
    with LOG_PATH.open("a") as log:
        log.write(f"\n## Weight Update — {datetime.now().isoformat(timespec='seconds')}\n")

        for row in rows:
            loop_id, status, created, feedback, priority, promoted = row
            weight = calculate_weight(status, created, feedback, promoted)
            cursor.execute("UPDATE loops SET weight = ? WHERE id = ?", (weight, loop_id))
            log.write(f"- `{loop_id}`: weight = {weight}, feedback = {feedback}, promoted = {promoted}, status = {status}\n")

    conn.commit()
    conn.close()
    print("✅ Loop weights updated and logged.")

if __name__ == "__main__":
    update_weights()
