"""
classify_structured_email_tasks.py

Classifies structured tasks from Signal_Tasks.md using Qdrant and appends topic tags.
"""

import openai
from qdrant_client import QdrantClient
from pathlib import Path

SIGNAL_FILE = Path("/Users/air/AIR01/0001-HQ/Signal_Tasks.md")
COLLECTION_NAME = "loop_embeddings"

client = openai.OpenAI()
qdrant = QdrantClient(host="localhost", port=6333)

def embed(text):
    response = client.embeddings.create(input=[text], model="text-embedding-3-small")
    return response.data[0].embedding

def classify_task(line):
    vector = embed(line)
    results = qdrant.search(collection_name=COLLECTION_NAME, query_vector=vector, limit=3, with_payload=True)
    top_tags = []

    for match in results:
        tags = match.payload.get("tags", [])
        top_tags.extend(tags)

    tag_counts = {}
    for tag in top_tags:
        tag_counts[tag] = tag_counts.get(tag, 0) + 1

    sorted_tags = sorted(tag_counts.items(), key=lambda x: x[1], reverse=True)
    return [f"#{tag}" for tag, _ in sorted_tags[:3]]

def classify_signal_file():
    lines = SIGNAL_FILE.read_text().splitlines()
    updated_lines = []

    for line in lines:
        if line.strip().startswith("- [ ]") and "#classified" not in line:
            content = line.split("Follow up on:")[-1].strip()
            tags = classify_task(content)
            updated_line = f"{line} {' '.join(tags)} #classified"
            updated_lines.append(updated_line)
        else:
            updated_lines.append(line)

    SIGNAL_FILE.write_text("\n".join(updated_lines))
    print("✅ Classified and updated Signal_Tasks.md")

if __name__ == "__main__":
    classify_signal_file()
