
import os
import json
from pathlib import Path
from datetime import datetime

# Paths
vault_path = Path("/Users/air/AIR01/0001-HQ/Signal_Tasks.md")
processed_path = Path.home() / "ea_assistant" / "gmail" / "processed_threads.json"
log_path = Path.home() / "ea_assistant" / "Logs" / "email_ingest_log.md"

# Ensure processed_threads.json exists
processed_path.parent.mkdir(parents=True, exist_ok=True)
if not processed_path.exists():
    processed_path.write_text("{}")

# Load processed thread IDs
with processed_path.open("r") as f:
    processed = json.load(f)

# Simulated incoming emails (in real use, replace this block with Gmail API results)
emails = [
    {
        "threadId": "test-" + datetime.now().strftime("%Y%m%d%H%M%S"),
        "subject": "Test Email Ingestion @ " + datetime.now().isoformat(),
        "from": "sender@example.com",
        "link": "https://mail.google.com/mail/u/0/#inbox/thread-id-placeholder"
    }
]

# Open task file for appending
with vault_path.open("a") as vault, log_path.open("a") as log:
    for email in emails:
        if email["threadId"] in processed:
            continue  # Already processed

        timestamp = datetime.now().isoformat()
        task_line = f"- [ ] Follow up on: {email['subject']} from {email['from']} — [View source]({email['link']}) threadId:{email['threadId']} #email #ingested_at:{timestamp}\n"

        vault.write(task_line)
        log.write(f"{timestamp} — Ingested: {email['subject']} (threadId: {email['threadId']})\n")

        processed[email["threadId"]] = True

# Save updated processed threads
with processed_path.open("w") as f:
    json.dump(processed, f)

print(f"✅ {len(emails)} new task(s) written to {vault_path}")
