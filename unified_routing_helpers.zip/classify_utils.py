
from random import random

# Placeholder for actual semantic classification logic using Qdrant
def classify_task_semantically(task, loops):
    results = []
    for loop in loops:
        results.append({
            "file": loop["file"],
            "type": loop["type"],
            "similarity": round(0.75 + 0.25 * random(), 3)  # Random high similarity for demo
        })
    return sorted(results, key=lambda x: x["similarity"], reverse=True)[:3]
