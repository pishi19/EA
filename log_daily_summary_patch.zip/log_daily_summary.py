
from datetime import datetime
from pathlib import Path

# Paths
VAULT_PATH = "/Users/air/AIR01"
DAILY_PATH = Path(VAULT_PATH) / "0001-HQ" / "Daily Assistant"
LOG_PATH = Path("/Users/air/Library/Logs/ora/daily_refresh.log")

def generate_summary():
    date_str = datetime.now().strftime("%Y-%m-%d")
    note_path = DAILY_PATH / f"{date_str}-assistant.md"

    # Extract recent summary from log
    if not LOG_PATH.exists():
        summary = "⚠️ No log found for today's refresh run."
    else:
        with open(LOG_PATH, "r", encoding="utf-8") as log_file:
            lines = log_file.readlines()
            recent = [line for line in lines if date_str in line]
            summary_lines = [line for line in recent if "✅" in line or "▶" in line or "❌" in line]
            summary = "".join(summary_lines).strip() or "⚠️ No tasks were logged."

    # Prepare note content
    note = f"""---
date: {date_str}
type: assistant_summary
tags: [#assistant, #daily, #refresh]
---

## ✅ Daily Assistant Summary

{summary}

→ View dashboard: [[loop_status.md]]

📅 Logged automatically from `daily_refresh.py`
"""

    DAILY_PATH.mkdir(parents=True, exist_ok=True)
    note_path.write_text(note, encoding="utf-8")
    print(f"✅ Daily assistant note written to: {note_path}")

if __name__ == "__main__":
    generate_summary()
