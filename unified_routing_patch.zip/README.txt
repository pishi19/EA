
Install Patch:
--------------

1. Move and unzip:
   mv ~/Downloads/unified_routing_patch.zip ~/ea_assistant/
   cd ~/ea_assistant/
   unzip -o unified_routing_patch.zip

2. Test:
   python3 route_tasks_to_programs_and_projects.py

Result:
- Routes structured tasks from Signal_Tasks.md
- Links to matching programs/projects in 02 Workstreams/
- Updates log files in System/Logs/
