
import os
import re
import datetime
from pathlib import Path
from classify_utils import classify_task_semantically
from file_utils import load_tasks_from_file, save_tasks_to_file, append_related_task_block
from trace_log_utils import log_trace

SIGNAL_TASKS_PATH = "/Users/air/AIR01/0001-HQ/Signal_Tasks.md"
PROGRAMS_DIR = "/Users/air/AIR01/02 Workstreams/Programs/"
PROJECTS_DIR = "/Users/air/AIR01/02 Workstreams/Projects/"
PROGRAM_LOG_PATH = "/Users/air/AIR01/System/Logs/program_trace_log.md"
PROJECT_LOG_PATH = "/Users/air/AIR01/System/Logs/project_trace_log.md"

DEFAULT_PROGRAM_CONF = 0.85
DEFAULT_PROJECT_CONF = 0.80

def ensure_file(path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    if not Path(path).exists():
        Path(path).write_text("")

def route_task(task, loops):
    if "#ignore" in task:
        return task, None

    # Classify semantically (stub)
    top_matches = classify_task_semantically(task, loops)
    modified_task = task
    routed_to = []

    for match in top_matches:
        target_type = match["type"]
        target_file = match["file"]
        target_id = Path(target_file).stem
        similarity = match["similarity"]

        if target_type == "program" and similarity >= DEFAULT_PROGRAM_CONF:
            modified_task += f" → [[{target_id}]] #programmed #routed"
            append_related_task_block(target_file, task)
            log_trace(PROGRAM_LOG_PATH, task, target_id, "program")
            routed_to.append(target_id)

        elif target_type == "project" and similarity >= DEFAULT_PROJECT_CONF:
            modified_task += f" → [[{target_id}]] #projected #routed"
            append_related_task_block(target_file, task)
            log_trace(PROJECT_LOG_PATH, task, target_id, "project")
            routed_to.append(target_id)

    return modified_task, routed_to

def main():
    ensure_file(SIGNAL_TASKS_PATH)
    ensure_file(PROGRAM_LOG_PATH)
    ensure_file(PROJECT_LOG_PATH)

    tasks = load_tasks_from_file(SIGNAL_TASKS_PATH)
    loops = []

    for file in Path(PROGRAMS_DIR).glob("*.md"):
        loops.append({"file": str(file), "type": "program"})

    for file in Path(PROJECTS_DIR).glob("*.md"):
        loops.append({"file": str(file), "type": "project"})

    updated_tasks = []
    for task in tasks:
        new_task, _ = route_task(task, loops)
        updated_tasks.append(new_task)

    save_tasks_to_file(SIGNAL_TASKS_PATH, updated_tasks)

if __name__ == "__main__":
    main()
