"""Processes Gmail ingestion."""

def ingest():
    pass
