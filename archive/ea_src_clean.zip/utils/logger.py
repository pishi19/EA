"""Logger setup."""

def log(msg):
    print(msg)
