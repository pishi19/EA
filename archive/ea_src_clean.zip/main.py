"""Main entry point."""

def main():
    pass
