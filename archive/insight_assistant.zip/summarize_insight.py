"""
summarize_insight.py

Uses GPT to summarize the content and generate tags + metadata.
"""

def summarize(content, tags):
    # Placeholder for GPT logic
    summary = content.strip()
    metadata = {
        "tags": tags,
        "type": "loop",
        "status": "open",
        "priority": "medium",
        "source": "manual"
    }
    return summary, metadata
