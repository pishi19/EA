# Memory

Loop memory and embedding layer: SQLite, Qdrant, pruning, weighting.

## Contents

- Description of key files here.
- Inputs/outputs.
- Data contracts or expectations.
- Related modules.
