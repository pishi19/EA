# Ingestion

Handles input from various sources (e.g., Gmail, iMessage, BambooHR).

## Contents

- Description of key files here.
- Inputs/outputs.
- Data contracts or expectations.
- Related modules.
