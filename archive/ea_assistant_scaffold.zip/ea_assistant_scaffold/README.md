# Ora EA Assistant

This repository contains the core infrastructure for the Ora Executive Assistant system.

## Quickstart (Cursor-Ready)

```bash
uv venv .venv
uv pip install -r uv.lock
source .venv/bin/activate
ruff check . --fix
black .
mypy ea_assistant/
```

## Modules

- `config/`: Configuration files for OAuth, API keys, and runtime settings.
- `ingestion/`: Handles input from various sources (e.g., Gmail, iMessage, BambooHR).
- `interface/`: UI components: Streamlit, CLI tools, Obsidian integration.
- `memory/`: Loop memory and embedding layer: SQLite, Qdrant, pruning, weighting.
- `tasks/`: Classification, routing, loop generation, and project promotion.
- `utils/`: Shared utilities: file ops, parsing, logging helpers.
- `tests/`: Unit and integration tests for all modules.
- `scripts/`: Automation scripts: install, launchd, cron jobs.