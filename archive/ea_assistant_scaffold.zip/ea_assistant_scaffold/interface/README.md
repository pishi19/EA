# Interface

UI components: Streamlit, CLI tools, Obsidian integration.

## Contents

- Description of key files here.
- Inputs/outputs.
- Data contracts or expectations.
- Related modules.
