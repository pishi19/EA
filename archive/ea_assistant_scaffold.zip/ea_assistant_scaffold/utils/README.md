# Utils

Shared utilities: file ops, parsing, logging helpers.

## Contents

- Description of key files here.
- Inputs/outputs.
- Data contracts or expectations.
- Related modules.
