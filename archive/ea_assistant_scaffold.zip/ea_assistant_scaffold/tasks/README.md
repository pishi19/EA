# Tasks

Classification, routing, loop generation, and project promotion.

## Contents

- Description of key files here.
- Inputs/outputs.
- Data contracts or expectations.
- Related modules.
