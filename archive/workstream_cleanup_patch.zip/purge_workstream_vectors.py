
from qdrant_client import QdrantClient

qdrant = QdrantClient("localhost", port=6333)
COLLECTION = "workstream_items"

def purge_workstream_vectors():
    print("🚨 Deleting all program/project vectors from Qdrant collection...")
    qdrant.delete(
        collection_name=COLLECTION,
        points_selector={"filter": {
            "must": [
                {"key": "type", "match": {"value": "program"}},
                {"key": "type", "match": {"value": "project"}}
            ]
        }}
    )
    print("✅ Purge complete.")

if __name__ == "__main__":
    purge_workstream_vectors()
