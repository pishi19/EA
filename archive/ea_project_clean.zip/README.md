# Ora Executive Assistant

Refactored project structure.