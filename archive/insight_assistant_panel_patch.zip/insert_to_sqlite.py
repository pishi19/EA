"""
insert_to_sqlite.py

Inserts the loop metadata into the SQLite loop memory DB.
"""

def insert_to_sqlite(loop_id, summary, metadata):
    # Placeholder for SQLite logic
    print(f"Inserted {loop_id} into SQLite with metadata: {metadata}")
