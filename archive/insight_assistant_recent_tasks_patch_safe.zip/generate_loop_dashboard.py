"""
generate_loop_dashboard.py

Creates a loop dashboard from loop_memory.db and writes to /0001-HQ/Dashboards/loop_status.md
"""

import sqlite3
from collections import Counter
from pathlib import Path
from datetime import datetime, date

DB_PATH = "/Users/air/ea_assistant/loop_memory.db"
DASHBOARD_PATH = Path("/Users/air/AIR01/0001-HQ/Dashboards/loop_status.md")
SIGNAL_FILE = Path("/Users/air/AIR01/0001-HQ/Signal_Tasks.md")

def get_loop_data():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT id, tags, status, priority, created, weight FROM loops")
    rows = cursor.fetchall()
    conn.close()
    return rows

def build_dashboard(data):
    total = len(data)
    open_loops = [row for row in data if row[2] == "open"]
    closed_loops = [row for row in data if row[2] == "closed"]
    priorities = Counter([row[3] for row in data])
    tag_counter = Counter()
    stale_loops = []
    weight_data = []

    for row in data:
        weight_data.append((row[0], row[5] if len(row) > 5 else 0))
    for row in open_loops:
        loop_date = date.fromisoformat(row[4])
        if (date.today() - loop_date).days > 14:
            stale_loops.append((row[0], (date.today() - loop_date).days))
        tag_counter.update(tag.strip() for tag in row[1].split(",") if tag)

    lines = []
    lines.append(f"# 📊 Loop Memory Dashboard  
_Last updated: {datetime.now().isoformat(timespec='minutes')}_\n")
    lines.append(f"- **Total loops:** {total}")
    lines.append(f"- **Open:** {len(open_loops)}  	**Closed:** {len(closed_loops)}")
    lines.append(f"- **High priority:** {priorities.get('high', 0)}  	Medium: {priorities.get('medium', 0)}  	Low: {priorities.get('low', 0)}\n")

    lines.append("## 🔖 Top Tags")
    for tag, count in tag_counter.most_common(10):
        lines.append(f"- `{tag}`: {count}")

    lines.append("\n## 🏋️ Top Weighted Loops")
    for loop_id, weight in sorted(weight_data, key=lambda x: x[1], reverse=True)[:5]:
        lines.append(f"- `{loop_id}`: weight {weight}")

    lines.append("\n## 🧭 Feedback Summary")
    # TODO: Feedback data already included earlier

    lines.append("\n## ⏳ Stale Open Loops (>14 days)")
    for loop_id, age in stale_loops:
        lines.append(f"- {loop_id} — {age} days old")

    # 📨 Recently Routed Tasks
    lines.append("\n## 📬 Recent Routed Tasks")
    if SIGNAL_FILE.exists():
        routed_lines = []
        for line in reversed(SIGNAL_FILE.read_text().splitlines()):
            if "#routed" in line:
                routed_lines.append(line)
            if len(routed_lines) >= 10:
                break
        lines.append("<details><summary>View</summary>\n")
        lines.extend(routed_lines)
        lines.append("</details>")

    return "\n".join(lines)

def main():
    DASHBOARD_PATH.parent.mkdir(parents=True, exist_ok=True)
    data = get_loop_data()
    dashboard = build_dashboard(data)
    with DASHBOARD_PATH.open("w") as f:
        f.write(dashboard)
    print(f"✅ Loop dashboard written to {DASHBOARD_PATH}")

if __name__ == "__main__":
    main()
