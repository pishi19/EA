#!/usr/bin/env python3
from pathlib import Path
import re
from datetime import datetime

loop_dir = Path("/Users/air/AIR01/Retrospectives")
dashboard_path = Path("/Users/air/AIR01/System/Dashboards/cursor_environment.md")

def get_loop_summaries():
    summaries = []
    for file in loop_dir.glob("loop-*.md"):
        with file.open() as f:
            content = f.read()
        loop_id = re.search(r"id:\s*(loop-[\d\-]+)", content)
        summary = re.search(r"summary:\s*(.*)", content)
        status = re.search(r"status:\s*(\w+)", content)
        if loop_id and summary and status:
            summaries.append(f"- **{loop_id.group(1)}**: {summary.group(1)} _({status.group(1)})_")
    return summaries

def patch_dashboard():
    if not dashboard_path.exists():
        return
    content = dashboard_path.read_text().split("---")
    if len(content) < 3:
        return
    header, meta, body = content
    sections = body.split("## 📋 TODO Summary")
    new_section = "## 🧠 Open Loop Summaries\n" + "\n".join(get_loop_summaries()) + "\n\n"
    updated_body = new_section + "## 📋 TODO Summary" + sections[1]
    full_output = f"---{meta}## 📊 Cursor-GPT Environment Dashboard\n\n" + updated_body
    dashboard_path.write_text(full_output)
    print("✅ Loop summaries added to dashboard.")

if __name__ == "__main__":
    patch_dashboard()
