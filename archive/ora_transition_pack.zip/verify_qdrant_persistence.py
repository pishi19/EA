import requests

response = requests.get("http://localhost:6333/collections")

if response.status_code == 200:
    data = response.json()
    if data['result']['collections']:
        print("✅ Persistence confirmed. Collections found:", [c['name'] for c in data['result']['collections']])
    else:
        print("⚠️ Qdrant is up but no collections found.")
else:
    print("❌ Qdrant is not responding. Status code:", response.status_code)