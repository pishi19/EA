"""Configuration management."""
CONFIG = {}
