"""Monitors file changes."""

def watch():
    pass
