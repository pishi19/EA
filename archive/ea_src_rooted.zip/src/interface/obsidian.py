"""Integrates with Obsidian."""

def sync():
    pass
