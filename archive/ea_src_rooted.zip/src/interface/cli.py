"""Command-line interface."""

def main():
    pass
