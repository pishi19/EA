"""
update_insight_panel.py

Appends a summary block to the loop_focus.md insight panel.
"""

from pathlib import Path

def update_insight_panel(loop_id, summary, metadata, file_path):
    panel = Path("/Users/air/AIR01/0001 HQ/Insights/loop_focus.md")
    block = f"""\n\n### 🧠 New Insight: {summary[:60]}\n
**Tags**: {metadata['tags']}  
**Status**: {metadata['status']}  
**Link**: [Open]({file_path})  
"""
    with panel.open("a") as f:
        f.write(block)
