"""
insert_to_qdrant.py

Embeds the summary and inserts it into Qdrant.
"""

def insert_to_qdrant(loop_id, summary, metadata):
    # Placeholder for Qdrant logic
    print(f"Embedded and inserted {loop_id} into Qdrant.")
